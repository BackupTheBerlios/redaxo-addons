// ----------------------------------------------------------------------------
// Mark It Up!
// ----------------------------------------------------------------------------
// Copyright (C) 2007 Jay Salvat
// http://markitup.jaysalvat.com/
// ----------------------------------------------------------------------------
// REDAXO tags
// http://redaxo.de
// http://en.wikipedia.org/wiki/html
// ----------------------------------------------------------------------------
// Basic set. Feel free to add more tags
// ----------------------------------------------------------------------------
redaxo_textile = {	nameSpace: "redaxo_textile",
	previewIFrame:	true,
	previewParserPath: "index.php",
	previewParserVar: "markitup_textile_preview",
  onShiftEnter:       {keepDefault:false, replaceWith:'\n\n'},
  markupSet: [     
    {name:'Heading 1', key:'1', openWith:'\nh1(!(([![Class]!])!). '}, 
    {name:'Heading 2', key:'2', openWith:'\nh2(!(([![Class]!])!). '}, 
    {name:'Heading 3', key:'3', openWith:'\nh3(!(([![Class]!])!). '}, 
    {name:'Heading 4', key:'4', openWith:'\nh4(!(([![Class]!])!). '}, 
    {name:'Heading 5', key:'5', openWith:'\nh5(!(([![Class]!])!). '}, 
    {name:'Heading 6', key:'6', openWith:'\nh6(!(([![Class]!])!). '}, 
    {name:'Paragraph', key:'P', openWith:'\np(!(([![Class]!])!). '}, 
    {separator:'---------------' },
    {name:'Bold', key:'B', closeWith:'*', openWith:'*'}, 
    {name:'Italic', key:'I', closeWith:'_', openWith:'_'}, 
    {name:'Stroke through', key:'S', closeWith:'-', openWith:'-'}, 
    {separator:'---------------' },
    {name:'Bulleted list', openWith:'(!(* |!|*)!)'}, 
    {name:'Numeric list', openWith:'(!(# |!|#)!)'}, 
    {separator:'---------------' },
		{name:'Picture', key:'P', beforeInsert:function() { openMediaPool('TINYIMG'); } },
		{name:'Link Picture', beforeInsert:function() { openMediaPool('TINY'); } },
		{name:'Link', key:'L', beforeInsert:function() { openLinkMap('TINY'); } },
    {separator:'---------------' },
    {name:'Quotes', openWith:'\nbq(!(([![Class]!])!)). '}, 
    {name:'Code', openWith:'@', closeWith:'@'}, 
    {separator:'---------------' },       
    {name:'Preview', call:'preview', className:'preview'}
  ]
}

function insertFileLink(file)
{
  $.markItUp({openWith:'"', closeWith:'":'+file});
}

function insertLink(url)
{
  $.markItUp({openWith:'"', closeWith:'":'+url});
}

function insertImage(src, desc)
{
  $.markItUp({replaceWith:"!"+ src +"("+ desc +")!"});
}